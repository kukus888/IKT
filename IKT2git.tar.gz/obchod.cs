﻿using System;

namespace IKT
{
	public class obchod
	{
		public obchod ()
		{
		}
	}
}

